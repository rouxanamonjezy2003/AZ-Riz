x=sin(0:pi/10:2*pi);
x=x*(511)+511;
x=round(x)

plot(x)
