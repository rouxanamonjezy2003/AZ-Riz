#include "lpc17xx_gpio.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_pwm.h"

#include "Delay_RIT.h"

const uint8_t segmentTable[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void DelayRefresh()
{
   for(uint32_t count=0;count<UINT16_MAX+40000;count++);  //6.4mS	    
}

int main()
{	
 PWM_TIMERCFG_Type pwmTimCfg;
 PWM_MATCHCFG_Type pwmMatch0;	
 PINSEL_CFG_Type  pwmPinsel;
	
	Delay_RIT_Init();
		pwmTimCfg.PrescaleOption=PWM_TIMER_PRESCALE_TICKVAL;
	pwmTimCfg.PrescaleValue=1;
	PWM_Init(LPC_PWM1,PWM_MODE_TIMER,&pwmTimCfg);

	pwmMatch0.IntOnMatch=DISABLE;
	pwmMatch0.MatchChannel=0;
	pwmMatch0.ResetOnMatch=ENABLE;
	pwmMatch0.StopOnMatch=DISABLE;
	
	PWM_ConfigMatch(LPC_PWM1,&pwmMatch0);
	
	PWM_MatchUpdate(LPC_PWM1,0,100,PWM_MATCH_UPDATE_NOW);
	
	PWM_ChannelCmd(LPC_PWM1,1,ENABLE);
	
	PWM_ResetCounter(LPC_PWM1);
	PWM_CounterCmd(LPC_PWM1,ENABLE);
	
	PWM_Cmd(LPC_PWM1,ENABLE);
	
	pwmPinsel.Funcnum=PINSEL_FUNC_1;
	pwmPinsel.OpenDrain=PINSEL_PINMODE_NORMAL;
	pwmPinsel.Pinmode=PINSEL_PINMODE_TRISTATE;
	pwmPinsel.Pinnum=0;
	pwmPinsel.Portnum=2;
	
	PINSEL_ConfigPin(&pwmPinsel);
	
	uint8_t j=0;
	uint16_t volatge,buff,temp,total;
	float    calcVolt;
	PINSEL_CFG_Type adcpinsel;
	
	adcpinsel.Funcnum=PINSEL_FUNC_1;
	adcpinsel.OpenDrain=PINSEL_PINMODE_NORMAL;
	adcpinsel.Pinmode=PINSEL_PINMODE_TRISTATE;
	adcpinsel.Pinnum=23;
	adcpinsel.Portnum=0;
	
	PINSEL_ConfigPin(&adcpinsel);
	
	ADC_Init(LPC_ADC,200000);
	ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_0,ENABLE);
	

	/*---7 Segment Data---*/
	FIO_ByteSetDir(1,2,0xff,1);
	
	/*---7 Segment Digits---*/
	GPIO_SetDir(0,(1<<1),1);
	GPIO_SetDir(0,(1<<2),1);
	GPIO_SetDir(0,(1<<3),1);
	
	GPIO_SetDir(1,(1<<26),1);
	
//	PWM_MatchUpdate(LPC_PWM1,1,100,PWM_MATCH_UPDATE_NOW);
//	Delay_RIT_ms(5000);	
	
while(1)
{		
  ADC_StartCmd(LPC_ADC,ADC_START_NOW);
	while(ADC_ChannelGetStatus(LPC_ADC,ADC_CHANNEL_0,ADC_DATA_DONE)==0)
	{
		
	}
	volatge=ADC_ChannelGetData(LPC_ADC,ADC_CHANNEL_0);
	/*
	 3        4096
	 x        volt
   x=volt*3/4096	
	*/
	
	calcVolt=(volatge*3.0F)/4096;
  buff=(calcVolt*100);
	total = total+buff;
	j++;
if (j==49){
   temp = total/50;
	j=0;
	total=0;
	buff=0;
}
	if(temp<=24 && temp>20)
	{
		GPIO_SetValue(1,(1<<26));	
	 PWM_MatchUpdate(LPC_PWM1,1,50,PWM_MATCH_UPDATE_NOW);		
	}
		if(temp<=27 && temp>25)
	{
		GPIO_SetValue(1,(1<<26));	
	 PWM_MatchUpdate(LPC_PWM1,1,70,PWM_MATCH_UPDATE_NOW);		
	}
			if(temp<=33 && temp>28)
	{
		GPIO_SetValue(1,(1<<26));	
	 PWM_MatchUpdate(LPC_PWM1,1,90,PWM_MATCH_UPDATE_NOW);		
	}
				if(temp>33)
	{
		GPIO_SetValue(1,(1<<26));	
	 PWM_MatchUpdate(LPC_PWM1,1,100,PWM_MATCH_UPDATE_NOW);		
	}
				if(temp<20)
	{
		GPIO_SetValue(1,(1<<26));	
	 PWM_MatchUpdate(LPC_PWM1,1,0,PWM_MATCH_UPDATE_NOW);		
	}
	
  GPIO_ClearValue(0,(1<<2));
	GPIO_SetValue(0,(1<<1));
	FIO_ByteSetValue(1,2,segmentTable[temp/10]);
	FIO_ByteClearValue(1,2,~segmentTable[temp/10]);
	Delay_RIT_ms(6);
	GPIO_ClearValue(0,(1<<1));
	GPIO_SetValue(0,(1<<2));
	FIO_ByteSetValue(1,2,segmentTable[temp%10]);
	FIO_ByteClearValue(1,2,~segmentTable[temp%10]);
	Delay_RIT_ms(6);

}
}
