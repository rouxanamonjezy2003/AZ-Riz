#ifndef Delay_RIT_H_
#define Delay_RIT_H_

#include <stdint.h>

void Delay_RIT_Init(void);
void Delay_RIT_ms(uint32_t timMs);

#endif
